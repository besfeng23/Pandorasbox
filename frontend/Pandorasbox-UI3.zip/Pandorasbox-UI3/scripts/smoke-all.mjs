import './smoke-local.mjs';
// Add any other smoke tests here


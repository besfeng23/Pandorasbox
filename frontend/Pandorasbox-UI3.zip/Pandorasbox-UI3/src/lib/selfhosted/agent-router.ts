
export function deriveAgentId(threadAgentId: string | undefined): string {
  // Placeholder for agent routing logic
  return threadAgentId || 'builder';
}


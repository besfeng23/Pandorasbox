// This file is for the Firebase configuration and is safe to be publicly exposed.
// Your project's security is enforced by your Firestore Security Rules and not by hiding these keys.

export const firebaseConfig = {
  apiKey: "AIzaSyBd6iZ2jEx1jmniBLD35no5gu1J4D4tSCM",
  authDomain: "seismic-vista-480710-q5.firebaseapp.com",
  projectId: "seismic-vista-480710-q5",
  storageBucket: "seismic-vista-480710-q5.firebasestorage.app",
  messagingSenderId: "536979070288",
  appId: "1:536979070288:web:57b05547304f0056526055"
};

import {genkit} from 'genkit';

// This is a LOCAL Genkit configuration for the Cloud Function.
// It is separate from the main application's Genkit config.
export const ai = genkit();
